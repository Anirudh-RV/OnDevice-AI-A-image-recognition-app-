package com.example.ondevicerecogcat;



import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.Camera;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    // Date : 03/07/19
    // functions done :
    /**
     * EXPLICIT PERMISSION ENABLED.
     * open the camera in a surface view using
     * public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {}
     *  to hold the surface view and have the camera in the same activity.
     *  Opening camera in the same activity
     * Taking a picture and displaying that picture
     * Switching the camera Front/Rear
     * */
    // comments from 56-91


    // Date : 05/07/19
    // fucntions done :
    /**
     * DOUBLE TAP for camera change.
     * Long press for taking a picture.
     * Other gesture functions added.
      */

    /** IMPORTANT FUNCTION
     *
     * Add auto focus.
     * Add focus on touch of the screen.
     */


    // Date : 07/07/19
    /**
     * Auto focus done.
     * Auto focus on touch of screen. done.
     * Added a camera button
     */

    // things to work on
    /**
     * Taking picture without freezing the phone. A stable and a better way of taking and storing pictures.
     * Run python scripts on android phone.
     */

    private Camera mCamera;
    private CameraPreview mPreview;
    private Camera.PictureCallback mPicture;
    private Button capture, switchCamera;
    private Context myContext;
    private LinearLayout cameraPreview;
    private boolean cameraFront = false;
    public static Bitmap bitmap;
    private final int REQUEST_CAMERA = 1;
    private int currentApiVersion;
    CameraPreview mCameraPreview;
    private static  final int FOCUS_AREA_SIZE= 300;

    private static Button clickpic;

    GestureDetector mGestureDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGestureDetector = new GestureDetector(this, this);

        clickpic = (Button) findViewById(R.id.clickpic);

        currentApiVersion = android.os.Build.VERSION.SDK_INT;
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                //TODO your background code
                currentApiVersion = android.os.Build.VERSION.SDK_INT;

                final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

                // This work only for android 4.4+
                if (currentApiVersion >= Build.VERSION_CODES.KITKAT) {

                    getWindow().getDecorView().setSystemUiVisibility(flags);

                    // Code below is to handle presses of Volume up or Volume down.
                    // Without this, after pressing volume buttons, the navigation bar will
                    // show up and won't hide
                    final View decorView = getWindow().getDecorView();
                    decorView
                            .setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {

                                @Override
                                public void onSystemUiVisibilityChange(int visibility) {
                                    if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                                        decorView.setSystemUiVisibility(flags);
                                    }
                                }
                            });
                }
            }
        });


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Check Permissions Now
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA);
        } else {
            // permission has been granted, continue as usual


            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


            myContext = this;

            mCamera = Camera.open();

            mCamera.setDisplayOrientation(90);
            cameraPreview = (LinearLayout) findViewById(R.id.cPreview);
            mPreview = new CameraPreview(myContext, mCamera);
            cameraPreview.addView(mPreview);


            // here is the function call that takes the picture.
            // call this with the gesture after.
            // once the gesture is done call the mCamera.takePicture() and python code to run the AI.
            // the pictures have to be taken continously.
            // for 4/07/19 do : function call when long press once.
            // end camera picture take function.
            // double tap for this function to switch the camera.
            // for 4/07/19 make the camera switch on double tap.
            // 5/07/19 : above comments functions done.

            mCamera.startPreview();



            // Function for taking picture
            clickpic.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Perform action on click

                }
            });

        }

    }


    // auto focus start :
    private Camera.AutoFocusCallback mAutoFocusTakePictureCallback = new Camera.AutoFocusCallback() {
        @Override
        public void onAutoFocus(boolean success, Camera camera) {
            if (success) {
                // do something...
                Log.i("tap_to_focus","success!");
            } else {
                // do something...
                Log.i("tap_to_focus","fail!");
            }
        }
    };
    private void focusOnTouch(MotionEvent event) {
        if (mCamera != null ) {

            Camera.Parameters parameters = mCamera.getParameters();
            if (parameters.getMaxNumMeteringAreas() > 0){
               // Log.i(TAG,"fancy !");
                Rect rect = calculateFocusArea(event.getX(), event.getY());

                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
                meteringAreas.add(new Camera.Area(rect, 800));
                parameters.setFocusAreas(meteringAreas);

                mCamera.setParameters(parameters);
                mCamera.autoFocus(mAutoFocusTakePictureCallback);
            }else {
                mCamera.autoFocus(mAutoFocusTakePictureCallback);
            }
        }
    }

    private Rect calculateFocusArea(float x, float y) {
        int left = clamp(Float.valueOf((x / mCameraPreview.getWidth()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        int top = clamp(Float.valueOf((y / mCameraPreview.getHeight()) * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);

        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private int clamp(int touchCoordinateInCameraReper, int focusAreaSize) {
        int result;
        if (Math.abs(touchCoordinateInCameraReper)+focusAreaSize/2>1000){
            if (touchCoordinateInCameraReper>0){
                result = 1000 - focusAreaSize/2;
            } else {
                result = -1000 + focusAreaSize/2;
            }
        } else{
            result = touchCoordinateInCameraReper - focusAreaSize/2;
        }
        return result;
    }
    // auto focus end.


// gesture functions added :
    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {

        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        int camerasNumber = Camera.getNumberOfCameras();
        if (camerasNumber > 1) {
            //release the old camera instance
            //switch camera, from the front and the back and vice versa

            releaseCamera();
            chooseCamera();
        } else {

        }
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {

        return true;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {

        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {

        return true;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {

        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {
       // mCamera.takePicture(null, null, mPicture);
    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {

        return true;
    }



    @Override
    public boolean onTouchEvent(MotionEvent event) {
       mGestureDetector.onTouchEvent(event);

       // camera focus :
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            focusOnTouch(event);
        }
        // end camera focus
        return super.onTouchEvent(event);
    }

    // end of gesture functions.

    // camera functions added:
        public void onRequestPermissionsResult(int requestCode,
        String[] permissions,
        int[] grantResults) {
            if (requestCode == REQUEST_CAMERA) {
                if(grantResults.length == 1
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // We can now safely use the API we requested access to
                    ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.CAMERA},100);

                } else {
                    // Permission was denied or request was cancelled
                }
            }
        }

    private int findFrontFacingCamera() {

        int cameraId = -1;
        // Search for the front facing camera
        int numberOfCameras = Camera.getNumberOfCameras();
        for (int i = 0; i < numberOfCameras; i++) {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(i, info);
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                cameraId = i;
                cameraFront = true;
                break;
            }
        }
        return cameraId;

    }

    private int findBackFacingCamera() {
        int cameraId = -1;
        //Search for the back facing camera
        //get the number of cameras
        int numberOfCameras = Camera.getNumberOfCameras();
        //for every camera check
        for (int i = 0; i < numberOfCameras; i++) {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(i, info);
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                cameraId = i;
                cameraFront = false;
                break;

            }

        }
        return cameraId;
    }
    // camera functions end.

    public void onResume() {

        super.onResume();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Check Permissions Now
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA);
        } else {
            try {
                // attempt to get a Camera instance
                if (mCamera == null) {
                    myContext = this;
                    mCamera = Camera.open();
                    mCamera.setDisplayOrientation(90);
                    mPicture = getPictureCallback();
                    mPreview.refreshCamera(mCamera);
                    Log.d("nu", "null");
                } else {
                    Log.d("nu", "no null");
                }
            }
            catch (Exception e){
            // Camera is not available (in use or does not exist)
// >>> HERE is your problem! Do not swallow exceptions silently!
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                MainActivity.this.startActivity(intent);
                if (MainActivity.this instanceof Activity) {
                    ((Activity) MainActivity.this).finish();
                }

                Runtime.getRuntime().exit(0);
            }

        }
    }

    // camera functions added :

    public void chooseCamera() {
        //if the camera preview is the front
        if (cameraFront) {
            int cameraId = findBackFacingCamera();
            if (cameraId >= 0) {
                //open the backFacingCamera
                //set a picture callback
                //refresh the preview

                mCamera = Camera.open(cameraId);
                mCamera.setDisplayOrientation(90);
                mPicture = getPictureCallback();
                mPreview.refreshCamera(mCamera);
            }
        } else {
            int cameraId = findFrontFacingCamera();
            if (cameraId >= 0) {
                //open the backFacingCamera
                //set a picture callback
                //refresh the preview
                mCamera = Camera.open(cameraId);
                mCamera.setDisplayOrientation(90);
                mPicture = getPictureCallback();
                mPreview.refreshCamera(mCamera);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        //when on Pause, release camera in order to be used from other applications
        releaseCamera();
    }

    private void releaseCamera() {
        // stop and release camera
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.release();
            mCamera = null;
        }
    }

    private Camera.PictureCallback getPictureCallback() {
        Camera.PictureCallback picture = new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(byte[] data, Camera camera) {
                bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                Intent intent = new Intent(MainActivity.this,PictureActivity.class);
                startActivity(intent);
            }
        };
        return picture;
    }

    // camera functions end.

}





